'use strict'

exports.list = (req, res) => {
    res.json({message: 'list'})
}

exports.create = (req, res) => {
    res.json({message: 'create'})
}

exports.show = (req, res) => {
    res.json({message: 'show'})
}

exports.edit = (req, res) => {
    res.json({message: 'edit'})
}

exports.remove = (req, res) => {
    res.json({message: 'remove'})
}
